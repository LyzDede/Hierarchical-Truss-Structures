function minVolume=G3_FMobjV(x,L)
    n1=x(1);
    n2=x(2);
    n3=x(3);
    r=x(4);
    
    num1=9*n1+9;
    num2=9*n2+9;
    num3=9*n3+9;
    
    L1 = sqrt(6) * L / (2 * n1 + 4);
    L2 = sqrt(6) * L1 / (2 * n2 + 4);
    L3 = sqrt(6) * L2 / (2 * n3 + 4);
    
    minVolume=num1*num2* L3*num3* pi*r*r;

end
    