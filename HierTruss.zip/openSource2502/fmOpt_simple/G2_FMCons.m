function [c,ceq]=G2_FMCons(x,L,F,E,k0)
    n1=x(1);
    n2=x(2);
    r=x(3);

    L1 = sqrt(6) * L / (2 * n1 + 4);
    L2 = sqrt(6) * L1 / (2 * n2 + 4);

    B = 0.245;
    k = pi * r * r*E/L2;
    k2=36*k/(11*n2+43);
    k1=36*k2/(11*n1+43);

    c(1)=F - B * (power(L1,3)) * k2 * pi * pi / (L * L);

    F1=F/sqrt(6);
    c(2)=F1 - B * (power(L2,3)) * k * pi * pi / (L1 * L1);

    F2=F1/sqrt(6);

    a=pi*r*r;
    c(3)=F2-pi*a*a*E/(4*power(L2,2));


    c(4)=k0*0.99-k1;
    c(5)=k1-k0*1.01;
    ceq=[];
end
    