format short;
E = 110000;
ts=950;
L=1000;F= 4000;k0=1000;

x0=[10 10 10 0.3];
lb=[0 0 0 0.001];
ub=[200 200 200 2000];

options = optimoptions('fmincon');
options.MaxIterations = 5000;
options.MaxFunctionEvaluations=80000;

[x,fval,exitflag,output,lambda] =fmincon(@(x) G3_FMobjV(x,L),x0,[],[],[],[],lb,ub,@(x) G3_FMCons(x,L,F,E,k0),options)
