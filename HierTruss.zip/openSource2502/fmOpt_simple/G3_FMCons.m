function [c,ceq]=G3_FMCons(x,L,F,E,k0)
    n1=x(1);
    n2=x(2);
    n3=x(3);
    r=x(4);
    
    L1 = sqrt(6) * L / (2 * n1 + 4);
    L2 = sqrt(6) * L1 / (2 * n2 + 4);
    L3 = sqrt(6) * L2 / (2 * n3 + 4);

    B = 0.245;
    k = pi * r * r*E/L3;
    
    k3=36*k/(11*n2+43);
    k2=36*k3/(11*n1+43);
    k1=36*k2/(11*n1+43);

    c(1)=F - B * (power(L1,3)) * k2 * pi * pi / (L * L);

    F1=F/sqrt(6);
    c(2)=F1 - B * (power(L2,3)) * k3 * pi * pi / (L1 * L1);

    F2=F1/sqrt(6);
    c(3)=F2 - B * (power(L3,3)) * k * pi * pi / (L2 * L2);

    F3=F2/sqrt(6);
    a=pi*r*r;
    c(4)=F3-pi*a*a*E/(4*power(L3,2));

    c(5)=k0*0.99-k1;
    c(6)=k1-k0*1.01;
    ceq=[];
end
    