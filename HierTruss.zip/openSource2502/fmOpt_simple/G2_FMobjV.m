function minVolume=G2_FMobjV(x,L)
    n1=x(1);
    n2=x(2);
    r=x(3);
    num1=9*n1+9;
    num2=9*n2+9;

    L1 = sqrt(6) * L / (2 * n1 + 4);
    L2 = sqrt(6) * L1 / (2 * n2 + 4);

    minVolume=num1*L2*num2*pi*r*r;

end
    