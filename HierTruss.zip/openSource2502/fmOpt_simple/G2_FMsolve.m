format short;
E = 100000;
ts=950;
    L=1000;F= 4000;k0= 1000;
x0=[15 45 0.3];
lb=[0 0 0.00001];
ub=[200 200 2000];

options = optimoptions('fmincon');
options.MaxIterations = 5000;
options.MaxFunctionEvaluations=80000;

[x,fval,exitflag,output,lambda] =fmincon(@(x) G2_FMobjV(x,L),x0,[],[],[],[],lb,ub,@(x) G2_FMCons(x,L,F,E,k0),options)
