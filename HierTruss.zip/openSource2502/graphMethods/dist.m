function d=dist(p1,p2)
    dp=p1-p2;
    d=sqrt(dp*dp');
    %d=sqrtm(dp*dp');
end
        